# Dice-Unity
Dice Game built in Unity


In this folder contains a .zip of the Unity Build, as well as the .apk to run on Android.
