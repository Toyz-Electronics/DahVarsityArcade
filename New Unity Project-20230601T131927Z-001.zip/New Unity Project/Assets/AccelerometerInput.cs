﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AccelerometerInput : MonoBehaviour {
    public int score;
    public Text scoreText;
    // Use this for initialization
    void Start () {
        score = 0;
        scoreText.text = "Score: " + score.ToString();
	}

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(transform.position.x);
        if (transform.position.y < 0 || transform.position.z != 8) //no physics for me!
        {
            transform.position = new Vector3(transform.position.x, 0, 8);
        }
        if (transform.position.x >= -2f && transform.position.x <= 2f)
        {

            transform.Translate( (-1f * Input.acceleration.x) / 4, 0, 0);

        }
        else if (transform.position.x > 2f)
        {
            transform.position = new Vector3(2f, transform.position.y,transform.position.z);
        }
        else if (transform.position.x < -2f)
        {
            transform.position = new Vector3(-2f, transform.position.y, transform.position.z);
        }
        //or do transform.position = old transform postion + input.acceleration
    }

    GameObject plane;
    GameObject planeWallL;
    GameObject planeWallR;
    GameObject planeWallA;
    Text text;
    GameObject gameScore;

    void OnCollisionEnter(Collision otherObj)
    {
        print(otherObj.gameObject.tag);
        if (otherObj.gameObject.tag == "balloon")
        {
            //balloonClone = GameObject.Find("balloon(Clone)");
            print("Destory clone");
            Destroy(otherObj.gameObject);
            plane = GameObject.Find("plane");
            planeWallL = GameObject.Find("planeWallL");
            planeWallR = GameObject.Find("planeWallR");
            planeWallA = GameObject.Find("planeWallA");
            Renderer pp = plane.GetComponent<Renderer>();
            Renderer pl = planeWallL.GetComponent<Renderer>();
            Renderer pr = planeWallR.GetComponent<Renderer>();
            Renderer pa = planeWallA.GetComponent<Renderer>();
            Renderer p = GetComponent<Renderer>();
            Renderer b = otherObj.gameObject.GetComponent<Renderer>();
            p.material.color = b.material.color;
            pp.material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), 1);
            pl.material.color = pp.material.color;
            pr.material.color = pl.material.color;
            pa.material.color = pr.material.color;
            score += 5;
            scoreText.text = "Score: " + score.ToString();
        }
    }

}
