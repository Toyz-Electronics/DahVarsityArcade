﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class ObjectsJustKeepFalling : MonoBehaviour {
    // Use this for initialization
    void Start()
    {
       
        //yield return new WaitForSeconds(5f);
        print("the makings of a new object");
        InvokeRepeating("balloonMaker", 5, 2);
        InvokeRepeating("balloonDestroyer", 10, 1);
       
    }
    // Update is called once per frame
    void Update () {
        
    }
    void balloonMaker()
    {
        GameObject balloonObj;
        Vector3 Positions = new Vector3(Random.Range(-2f, 2f),2, 2);
        balloonObj = GameObject.Find("Balloons");
        Renderer r = balloonObj.GetComponent<Renderer>();
        r.material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
        Instantiate(balloonObj, Positions, transform.rotation);
        
        //yield return new WaitForSeconds(5f);
        print("the makings of a new object");
        
    }
    GameObject balloonGoes;
    void balloonDestroyer()
    {
        //need to figure out how to destroy all clones
        balloonGoes = GameObject.Find("Balloons(Clone)");
        if (balloonGoes != null)
        {
            if (balloonGoes.transform.position.z > 10)
            {
                Debug.Log("Destory clone by falling");
                Destroy(balloonGoes);
            }
        }
    }
    
}
