﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {
    float xFactor = Screen.width / 400f;
    float yFactor = Screen.height / 400f;
    // Use this for initialization
    void Start () {
        Camera.main.rect = new Rect(0, 0, 1, xFactor / yFactor);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
