﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TileScript : MonoBehaviour {

	private float red;
	private float green;
	private float blue;
	public static Color paintColor;
	bool flipped = false;
	public bool special;
	public GameObject gameManager;
	public SceneGeneratorScript managerScript;
	private int gameMode;
	public Image crosshair1;
	public Image crosshair2;
	public int c = 0;

	// Use this for initialization
	void Start () {
		managerScript = gameManager.GetComponent<SceneGeneratorScript> ();
	}

	public void setColor(float r, float g, float b) {
		red = r;
		green = g;
		blue = b;
		Renderer ren = GetComponent<Renderer> ();
		ren.material.color = new Color (red, green, blue);
		gameMode = managerScript.gameMode;
		Debug.Log (gameMode);
		managerScript.tiles.Add (gameObject);
		managerScript.allTiles.Add (gameObject);
		if (gameMode >= 1)
			setTarget ();
	}

	public void changeColor() {
		c++;
		if (c == 8)
			c = 0;
		if (c == 0)
			paintColor = Color.black;
		if (c == 1)
			paintColor = Color.blue;
		if (c == 2)
			paintColor = Color.cyan;
		if (c == 3)
			paintColor = Color.green;
		if (c == 4)
			paintColor = Color.yellow;
		if (c == 5)
			paintColor = Color.red;
		if (c == 6)
			paintColor = Color.magenta;
		if (c == 7) 
			paintColor = Color.gray;
		if (gameMode == 2) {
			crosshair1.color = paintColor;
			crosshair2.color = paintColor;
			red = paintColor.r;
			green = paintColor.g;
			blue = paintColor.b;
		}

	}
	
	public void setTarget() {
		Renderer ren = GetComponent<Renderer> ();
		float otherColor = 0f;
		if (red + green + blue < 1.5f || gameMode == 2)
			otherColor = 1f;
		ren.material.color = new Color (otherColor, otherColor, otherColor);
		flipped = true;
		if (!managerScript)
			Debug.Log ("No manager script");
		managerScript.tiles.Remove (gameObject);
	}

	public void resetColor () {
		if (flipped) {
			Renderer ren = GetComponent<Renderer> ();
			ren.material.color = new Color (red, green, blue);
			if (gameMode == 2)
				ren.material.color = paintColor;
			flipped = false;
			managerScript.tiles.Add (gameObject);
		} else
			setTarget ();
	}

	// Update is called once per frame
	void Update () {
		/*if (Random.Range (0, 80000) == 42 && !flipped)
			setTarget ();*/
	}
}
