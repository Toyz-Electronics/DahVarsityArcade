﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SceneGeneratorScript : MonoBehaviour {

	public GameObject tilePrefab;
	public GameObject yPlane;
	public GameObject xPlane;
	public GameObject zPlane;
	public GameObject yPlane2;
	public GameObject xPlane2;
	public GameObject zPlane2;
	public GameObject button0;
	public GameObject button1;
	public GameObject button2;
	public Canvas canvas;
	public List<GameObject> tiles = new List<GameObject>();
	public List<GameObject> allTiles = new List<GameObject> ();
	public static float canvasDistance;
	public int gameMode = 0;  // 0 = race, 1 = quick fill, 2 = paint
	public float delay = 1f;
	private float time = 0;
	private float elapsedTime = 0f;

	// Use this for initialization
	void Start () {
		//Instantiate (floorPlane, new Vector3(0.5f+1f, 0.5f, 0.5f), floorPlane.transform.rotation);
		//generateRoom();
	}

	public void restartGame() {
		while (allTiles.Count > 0) {
			GameObject tileObject = allTiles [0];
			allTiles.RemoveAt (0);
			Destroy (tileObject);
		}
	}

	public void generateRoom () {
		for (float i = 0; i < 8; i+=1) {
			for (float j = 0; j < 8; j+=1) {
				GameObject Y = (GameObject)Instantiate (tilePrefab, new Vector3 (0.5f + i, 0, 0.5f + j), yPlane.transform.rotation);
				GameObject X = (GameObject)Instantiate (tilePrefab, new Vector3 (0, 0.5f + i, 0.5f + j), xPlane.transform.rotation);
				GameObject Z = (GameObject)Instantiate (tilePrefab, new Vector3 (0.5f + i, 0.5f + j, 0), zPlane.transform.rotation);
				TileScript yScript = Y.GetComponent<TileScript> ();
				TileScript xScript = X.GetComponent<TileScript> ();
				TileScript zScript = Z.GetComponent<TileScript> ();
				yScript.setColor (i / 8, j / 8, 0);
				xScript.setColor (0, j / 8, i / 8);
				zScript.setColor (i / 8, 0, j / 8);
				GameObject Y2 = (GameObject)Instantiate (tilePrefab, new Vector3 (0.5f + i, 8, 0.5f + j), yPlane2.transform.rotation);
				GameObject X2 = (GameObject)Instantiate (tilePrefab, new Vector3 (8, 0.5f + i, 0.5f + j), xPlane2.transform.rotation);
				GameObject Z2 = (GameObject)Instantiate (tilePrefab, new Vector3 (0.5f + i, 0.5f + j, 8), zPlane2.transform.rotation);
				TileScript yScript2 = Y2.GetComponent<TileScript> ();
				TileScript xScript2 = X2.GetComponent<TileScript> ();
				TileScript zScript2 = Z2.GetComponent<TileScript> ();
				yScript2.setColor (i / 8, j / 8, 1);
				xScript2.setColor (1, j / 8, i / 8);
				zScript2.setColor (i / 8, 1, j / 8);
			}
		}
	}

	//Flip random tile
	void randomFlip () {
		int i = Random.Range (0, tiles.Count);
		TileScript tile = tiles [i].GetComponent<TileScript> ();
		tile.setTarget ();

	}

	// Update is called once per frame
	void Update () {
		time += Time.deltaTime;
		elapsedTime += Time.deltaTime;
		canvas.planeDistance = canvasDistance;
		if (gameMode == 0) {
			if (tiles.Count == 0) {
				//game over!
			}
			else if (elapsedTime > delay) {
				randomFlip ();
				if (delay > 1)
					delay -= 0.09f;
				elapsedTime = 0f;
			}

		}
		if (Input.GetKeyDown (KeyCode.Escape)) {
			if (button0.activeSelf) {
				button0.SetActive (false);
				button1.SetActive (false);
				button2.SetActive (false);
			} else {
				button0.SetActive (true);
				button1.SetActive (true);
				button2.SetActive (true);
			}
		}

		//Camer look and click
		RaycastHit seen;
		Ray raydirection = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
		bool hit = Input.GetMouseButtonDown(0) || Input.GetKey (KeyCode.Joystick1Button0) 
			|| Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(1);
		if (Physics.Raycast(raydirection, out seen, 100))
		{				
			if (hit) {
				if (seen.collider.gameObject.tag == "button") {
					buttonScript button = seen.collider.gameObject.GetComponent<buttonScript> ();
					button.startGame ();
				} else if (seen.collider.gameObject.tag == "tile") {
					TileScript seenTile = seen.collider.gameObject.GetComponent<TileScript> ();
					if (Input.GetMouseButtonDown (1))
						seenTile.changeColor ();
					else
						seenTile.resetColor ();
				}
			}
			SceneGeneratorScript.canvasDistance = seen.distance - 0.4f;
		}
		Debug.DrawRay(transform.position, transform.forward, Color.black, 1); //unless you allow debug to be seen in game, this will only be viewable in the scene view

	}
}
