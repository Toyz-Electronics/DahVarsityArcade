﻿using UnityEngine;
using System.Collections;

public class StartSceneScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.touchCount > 0) {
			Application.LoadLevel("Game");
		}
		if (Input.anyKeyDown)
			Application.LoadLevel ("Game");
	}
}
