using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManagerScript : MonoBehaviour {

	public bool inGame = false;
	public float time = 0f;
	public float delay = 0.5f;
	public GameObject trashPrefab;
	public GameObject bottlePrefab;
	public GameObject can;
	public GameObject trash;
	public int canPos;
	public int counter = 3;
	public Text scoreLabel;
	public Text tutLabel1;
	public int score = 0;

	// Use this for initialization
	void Start () {
	
	}
	
	public void addScore () {
		score++;
		scoreLabel.text = score.ToString();
	}

	public void gameOver () {
		Application.LoadLevel("start");
	}

	// Update is called once per frame
	void Update () {
		time +=  Time.deltaTime;
		if (inGame && (time > delay)) {
			time = 0;
			produceTrash();
		}

		Vector2 touchSpot = new Vector2 (0, 0);
		bool touchedNow = false;
		//float butX = pauseplay.transform.position.x;
		//float butY = pauseplay.transform.position.y;
		for (int i = 0; i < Input.touchCount; ++i) {
			if (Input.GetTouch (i).phase == TouchPhase.Began) {
				// Construct a ray from the current touch coordinates
				touchSpot = Input.GetTouch (i).position;
				touchedNow = true;
			}
		}
		if (!inGame && (touchedNow || Input.anyKeyDown)) {
			if (counter > 0) {
				counter--;
			} 
			if (counter == 0) {
				inGame = true;
				tutLabel1.text = "";
			}
			if (counter == 1) {
				tutLabel1.text = "Get the bottle in the recycle bin\nand the trash in the trash\ntap to begin";
			}
		}
		if (can.transform.position.x < 0 && (touchedNow || Input.anyKeyDown)) {
			//Move right
			can.transform.position = new Vector3 (2f, -3.13f, 0);
			trash.transform.position = new Vector3 (-2f, -3.13f, 0);
			canPos = 1;
		} else if (can.transform.position.x > 0 && (touchedNow || Input.anyKeyDown)) {
			can.transform.position = new Vector3 (-2f, -3.13f, 0);
			trash.transform.position = new Vector3 (2f, -3.13f, 0);
			canPos = -1;
		}

		//if (inGame && )
	
	}

	// Create a piece of trash
	void produceTrash () {
		int i = Random.Range(0,2);
		if (i==0) i=-1;
		GameObject Z = (GameObject)Instantiate (trashPrefab, new Vector3 (2*i, 7, 0), Quaternion.identity);
		GameObject Q = (GameObject)Instantiate (bottlePrefab, new Vector3 (-2*i, 7, 0), Quaternion.identity);
		GarbageScript zScript = Z.GetComponent<GarbageScript> ();
		zScript.GMS = this;
		zScript.bottle = Q;
	}

}
