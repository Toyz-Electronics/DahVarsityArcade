﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GarbageScript : MonoBehaviour {

	public GameManagerScript GMS;
	public Transform thisthing;
	public bool noMore = false;
	public float timeLeft = 0.02f;
	public Renderer ren;
	public int score = 0;
	public GameObject bottle;

	// Use this for initialization
	void Start () {
		ren = GetComponent <Renderer> ();
	}

	// Update is called once per frame
	void Update () {
		if (thisthing.position.y < -2.83f && !noMore) {
			noMore = true;
			if (GMS.canPos < 0 && thisthing.position.x > 0) {
				GMS.addScore();
			}
			else if (GMS.canPos > 0 && thisthing.position.x < 0) {
				GMS.addScore();
			}
			else {
				Debug.Log("gameovver");
				GMS.gameOver();
			}
		}
		if (noMore) {
			GameObject.Destroy(this.gameObject);
			GameObject.Destroy (bottle);
		}

		/*if (noMore && timeLeft > 0) {
			timeLeft -= Time.deltaTime;
			ren.material.color = new Color (ren.material.color.r, ren.material.color.g, ren.material.color.b, timeLeft/(0.02f));
		}
		else if (noMore) {
			noMore = false;
			GameObject.Destroy(this.gameObject);
			timeLeft = 0.02f;
		}*/
	}

}
